package Macchiato;

import Polecenia.*;

import java.nio.file.Path;
import java.util.Scanner;

public class Debugger {
    private Macchiato program;
    private String wczytajPolecenie()
    {
        Scanner nowalinia = new Scanner(System.in);
        System.out.println("Proszę podać poprawne polecenie:");
        return nowalinia.nextLine();
    }
    private int getNumer(String komenda)
    {
        int indeks = 2;
        while (komenda.charAt(indeks) == ' ') // Omija spacje.
        {
            indeks++;
        }
        int numer = 0;
        int nowacyfra;
        for (int i = 0; i < komenda.length() - indeks; i++) // Od 3 miejsca w komendzie.
        {
            numer = numer * 10;
            nowacyfra = komenda.charAt(indeks + i) - '0';
            if (nowacyfra > -1 && nowacyfra < 10)
            {
                numer += nowacyfra;
            }
            else // kolejny znak nie jest cyfrą.
            {
                return -1;
            }
        }
        return numer;
    }
    private String getŚcieżka(String komenda)
    {
        String ścieżka = "";
        for (int i = 2; i < komenda.length(); i++)
        {
            ścieżka = ścieżka + komenda.charAt(i);
        }
        return ścieżka;
    }
    public void kolejnePolecenie() {
        String komenda = wczytajPolecenie(); // Sczytuje komendę.
        int[] dane;
        if (komenda.charAt(0) == 'c') { // Puszcza program, aż do zakończenia.
            new Continue(program).wykonajPolecenie();
        } else if (komenda.charAt(0) == 'e') { // Kończy program.
            new Exit(program).wykonajPolecenie();
        } else if (komenda.charAt(0) == 'd') { // Wyświetla zmienne na danym poziomie.
            new Display(getNumer(komenda), program).wykonajPolecenie();
        } else if (komenda.charAt(0) == 's') { // Wykonuje 'ile' kroków i wypisuje kolejną komendę.
            new Step(getNumer(komenda), program).wykonajPolecenie();
        } else if (komenda.charAt(0) == 'm') { // Wpisuje do pliku o podanej ścieżce display od 0 oraz widoczne procedury.
            new Dump(getŚcieżka(komenda), program).wykonajPolecenie();
        }
    }
    public Debugger(Macchiato program) {
        this.program = program;
    }
}

