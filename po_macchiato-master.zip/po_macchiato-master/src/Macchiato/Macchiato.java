package Macchiato;

import Instrukcje.*;
import Procedury.Procedura;
import Wyrażenia.*;

import java.util.Stack;

public class Macchiato {
    private int wykonwyaneprocedury = 0; // Ile procedur zagnieżdżonych w sobie się wykonuje.
    private Stack<Procedura> deklarowaneprocedury; // Jakie procedury są aktualnie deklarowane.
    private Blok[] bloki = new Blok[2]; // Tablica z blokami.
    private int zagnieżdżenie = -1; // Poziom zagnieżdżenia.
    private int aktualnyblok = -1; // Z którego poziomu zagnieżdżenia blok obsługuje.
    private boolean pierwszyruch = false; // Czy program wykonał pierwszą instrukcję.
    private boolean koniecprogramu = false; // Czy należy skończyć program.

    // Tworzy nowy blok.
    public Blok nowyBlok()
    {
        return new Blok(this);
    }

    // Tworzy nową instrukcję warunkową. (Używany, gdy trzeba podać instrukcję w pętli lub instrukcji warunkowej)
    public InstrukcjaWarunkowa nowaInstrukcjaWarunkowa(Wyrażenie wyrażenie1, String symbol, Wyrażenie wyrażenie2,
                                                       Instrukcja instrukcja)
    {
        return new InstrukcjaWarunkowa(wyrażenie1, symbol, wyrażenie2, instrukcja, bloki[zagnieżdżenie]);
    }

    // Tworzy nową instrukcję warunkową. (Używany, gdy trzeba podać instrukcję w pętli lub instrukcji warunkowej)
    public InstrukcjaWarunkowa nowaInstrukcjaWarunkowa(Wyrażenie wyrażenie1, String symbol, Wyrażenie wyrażenie2,
                                                       Instrukcja instrukcja1, Instrukcja instrukcja2)
    {
        return new InstrukcjaWarunkowa(wyrażenie1, symbol, wyrażenie2, instrukcja1, instrukcja2, bloki[zagnieżdżenie]);
    }

    // Tworzy nową pętlę. (Używany, gdy trzeba podać instrukcję w pętli lub instrukcji warunkowej)
    public Pętla nowaPętla(Zmienna zmienna, Wyrażenie wyrażenie, Instrukcja[] instrukcje)
    {
        return new Pętla(zmienna, wyrażenie, instrukcje, bloki[zagnieżdżenie]);
    }

    // Tworzy nowego printa. (Używany, gdy trzeba podać instrukcję w pętli lub instrukcji warunkowej)
    public Print nowyPrint(Wyrażenie wyrażenie)
    {
        return new Print(wyrażenie);
    }

    // Tworzy nową zmianę wartości zmiennej. (Używany, gdy trzeba podać instrukcję w pętli lub instrukcji warunkowej)
    public ZmieńWartośćZmiennej nowyZmieńWartośćZmiennej(char nazwa, Wyrażenie wyrażenie)
    {
        return new ZmieńWartośćZmiennej(nazwa, wyrażenie, bloki[zagnieżdżenie]);
    }
    // Tworzy nową aktywację procedury. (Używany, gdy trzeba podać instrukcję w pętli lub instrukcji warunkowej)
    public WykonajProcedurę noweWykonajProcedurę(String nazwa, Wyrażenie[] argumenty)
    {
        Procedura wykonywana;
        if (deklarowaneprocedury.empty())
        {
            wykonywana = bloki[zagnieżdżenie].getProcedura(nazwa);
        }
        else
        {
            Procedura aktualna = deklarowaneprocedury.pop();
            wykonywana = aktualna.getProcedura(nazwa);
            deklarowaneprocedury.push(aktualna);
        }
        return new WykonajProcedurę(wykonywana, this, argumenty, bloki[zagnieżdżenie]);
    }

    // Tworzy i dodaje nowy blok w programie. Rozpoczyna nowy blok. (Od tego momentu nowe instrukcje są do niego dopisywane)
    public Macchiato stwórzBlok()
    {
        Blok blok = nowyBlok();
        zagnieżdżenie--;
        dodajDoBloku(blok); // Dodaje polecenie stworzenia bloku do bloku o poziom niżej.
        zagnieżdżenie++;
        return this;
    }

    // Tworzy i dodaje nową aktywację procedury w aktualnym bloku.
    public Macchiato stwórzWykonajProcedurę(String nazwa, Wyrażenie[] argumenty)
    {
        WykonajProcedurę wykonajprocedurę = noweWykonajProcedurę(nazwa, argumenty);
        dodajDoBloku(wykonajprocedurę);
        return this;
    }
    // Tworzy i dodaje nową instrukcję warunkową w aktualnym bloku.
    public Macchiato stwórzInstrukcjaWarunkowa(Wyrażenie wyrażenie1, String symbol, Wyrażenie wyrażenie2,
                                               Instrukcja instrukcja)
    {
        InstrukcjaWarunkowa instrukcjawarunkowa = nowaInstrukcjaWarunkowa(wyrażenie1, symbol, wyrażenie2,
                instrukcja);
        dodajDoBloku(instrukcjawarunkowa); // Dodaje polecenie stworzenia instrukcji warunkowej do bloku o poziom niżej.
        return this;
    }

    // Tworzy i dodaje nową instrukcję warunkową w aktualnym bloku.
    public Macchiato stwórzInstrukcjaWarunkowa(Wyrażenie wyrażenie1, String symbol, Wyrażenie wyrażenie2,
                                               Instrukcja instrukcja1, Instrukcja instrukcja2)
    {
        InstrukcjaWarunkowa instrukcjawarunkowa = nowaInstrukcjaWarunkowa(wyrażenie1, symbol,
                wyrażenie2, instrukcja1, instrukcja2);
        dodajDoBloku(instrukcjawarunkowa); // Dodaje polecenie stworzenia instrukcji warunkowej do bloku o poziom niżej.
        return this;
    }

    // Tworzy i dodaje nową pętlę for w aktualnym bloku.
    public Macchiato stwórzPętla(Zmienna zmienna, Wyrażenie wyrażenie, Instrukcja[] instrukcje)
    {
        Pętla pętla = nowaPętla(zmienna, wyrażenie, instrukcje);
        dodajDoBloku(pętla);
        return this;
    }

    // Tworzy i dodaje nowego printa w aktualnym bloku.
    public Macchiato stwórzPrint(Wyrażenie wyrażenie)
    {
        Print print = nowyPrint(wyrażenie);
        dodajDoBloku(print);
        return this;
    }

    // Tworzy i dodaje nową zmianę wartości zmiennej w aktualnym bloku.
    public Macchiato stwórzZmieńWartośćZmiennej(char nazwa, Wyrażenie wyrażenie)
    {
        ZmieńWartośćZmiennej zmieńwartośćzmiennej = nowyZmieńWartośćZmiennej(nazwa, wyrażenie);
        dodajDoBloku(zmieńwartośćzmiennej);
        return this;
    }

    // Dodaje blok do tablicy bloków w programie.
    public void dodajBlok(Blok blok)
    {
        if (blok.getZagnieżdżenie() == bloki.length)
        {
            Blok[] nowebloki = new Blok[bloki.length * 2];
            for (int i = 0; i < bloki.length; i++)
            {
                nowebloki[i] = bloki[i];
            }
            bloki = nowebloki;
        }
        bloki[blok.getZagnieżdżenie()] = blok;
        zagnieżdżenie++;
    }

    // Dodaje instrukcję do bloku.
    private void dodajDoBloku(Instrukcja nowainstrukcja)
    {
        if (zagnieżdżenie > -1) {
            bloki[zagnieżdżenie].dodajInstrukcję(nowainstrukcja);
        }
    }

    // Wykonuje określoną ilość kroków lub kończy wcześniej, jeśli skończyły się kroki.
    public void kolejneKroki(int ile)
    {
        if (ile != 0 && !pierwszyruch) // Jeśli pierwsza instrukcja jest wykonywana.
        {
            pierwszyruch = true;
            bloki[0].wykonujInstrukcję();
            ile--;
        }
        while (ile != 0 && aktualnyblok > -1) // Wykonuje 'ile' kroków.
        {
            bloki[aktualnyblok].wykonujInstrukcję();
            ile--;
        }
        if (aktualnyblok == -1) // Jeśli skończyły się kroki.
        {
            koniecprogramu = true;
        }
    }
    public void kolejnaProcedura() // Zwiększa ilość aktualnie zagnieżdżonych w sobie wykonywujących się procedur.
    {
        wykonwyaneprocedury++;
    }
    public void skończonaProcedura() // Zmniejsza ilość aktualnie zagnieżdżonych w sobie wykonywujących się procedur.
    {
        wykonwyaneprocedury--;
    }
    // Wykonuje program. 'tryb' oznacza włącznie lub wyłączenie debuggera. (true - z debuggerem, false - bez debuggera)
    public Macchiato wykonajMacchiato(boolean tryb)
    {
        if (tryb == true) // Jeśli używany jest debugger.
        {
            Debugger debugger = new Debugger(this);
            while (!koniecprogramu) { // Póki nie zakończył się program.
                debugger.kolejnePolecenie();
            }
        }
        else if (tryb == false) // Z debuggerem
        {
            kolejneKroki(-1);
        }
        System.out.println("Program się zakończył.");
        return this;
    }



    // Deklaruje nową zmienna w aktulanym bloku.
    public Macchiato deklarujZmienną(char nazwa, Wyrażenie wyrażenie)
    {
        if (deklarowaneprocedury.empty())
        {
            bloki[zagnieżdżenie].deklaracjaZmiennej(nazwa, wyrażenie);
        }
        else {
            Procedura aktualna = deklarowaneprocedury.pop();
            aktualna.dodajZmienną(nazwa, wyrażenie);
            deklarowaneprocedury.push(aktualna);
        }
        return this;
    }

    // Zaczyna deklarację nowej procedury.
    public Macchiato zacznijDeklaracjęProcedury(String nazwa, char[] parametry)
    {
        if (deklarowaneprocedury.empty()) {
            bloki[zagnieżdżenie].deklaracjaProcedury(nazwa, parametry);
            deklarowaneprocedury.push(bloki[zagnieżdżenie].getProcedura(nazwa));
        }
        else
        {
            Procedura aktualna = deklarowaneprocedury.pop();
            Procedura nowa = new Procedura(nazwa, parametry, aktualna.getZmienne(), aktualna.getIleZmiennych(), aktualna.getBlok(), aktualna.getProcedury(), aktualna.getIleProcedur());
            aktualna.dodajProcedurę(nowa);
            deklarowaneprocedury.push(aktualna);
            deklarowaneprocedury.push(nowa);

        }
        return this;
    }

    // Kończy deklarację nowej procedury.
    public Macchiato skończDeklaracjęProcedury(Instrukcja[] treść)
    {
        Procedura aktualna = deklarowaneprocedury.pop();
        aktualna.setTreść(treść);
        return this;
    }
    public void zwiększAktualnyBlok()
    {
        aktualnyblok++;
    }
    public void skończAktualnyBlok() { aktualnyblok--; }
    public Macchiato koniecBloku()
    {
        zagnieżdżenie--;
        return this;
    }

    public Zmienna getZmienna(char nazwa)
    {
        if (deklarowaneprocedury.empty()) { // Jeśli nie jest deklarowana procedura.
            return bloki[zagnieżdżenie].getZmienna(nazwa);
        }
        else // Jeśli jest deklarowana procedura.
        {
            Procedura aktualna = deklarowaneprocedury.pop();
            Zmienna zmienna = aktualna.getZmienna(nazwa);
            deklarowaneprocedury.push(aktualna);
            return zmienna;
        }
    }
    public int getAktualnyBlok()
    {
        return aktualnyblok;
    }
    public int getZagnieżdżenie() { return zagnieżdżenie; }
    public Blok[] getBloki() { return bloki; }
    public boolean getPierwszyRuch() {return pierwszyruch;}
    public boolean getKoniecProgramu()
    {
        return koniecprogramu;
    }
    public int getWykonwyaneProcedury()
    {
        return wykonwyaneprocedury;
    }
    public void setKoniecProgramu(boolean koniec) {
        this.koniecprogramu = koniec;
    }

    public Macchiato(){
        deklarowaneprocedury = new Stack<Procedura>();
    }
}
