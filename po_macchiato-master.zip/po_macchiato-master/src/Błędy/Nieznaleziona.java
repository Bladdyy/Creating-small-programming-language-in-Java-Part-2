package Błędy;

public class Nieznaleziona extends Exception{

    // Wyjątek, który jest używany, gdy zmienna nie znajduje się w danym bloku.
    public Nieznaleziona(String napis) {
        super(napis);
    }
}
