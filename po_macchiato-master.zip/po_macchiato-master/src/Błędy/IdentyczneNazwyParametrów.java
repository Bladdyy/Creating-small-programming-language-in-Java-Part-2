package Błędy;

public class IdentyczneNazwyParametrów extends ArithmeticException{

    // Wyjątek, który jest używany, gdy w jednej procedurze są parametry o tych samych nazwach.
    public IdentyczneNazwyParametrów(String napis) {
        super(napis);
    }
}