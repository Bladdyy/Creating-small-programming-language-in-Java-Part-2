package Błędy;

public class DzieleniePrzezZero extends ArithmeticException{

        // Wyjątek, który jest używany, gdy program próbuje dzielić przez zero.
        public DzieleniePrzezZero(String napis) {
        super(napis);
    }
}
