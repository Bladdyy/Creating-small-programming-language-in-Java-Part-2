package Błędy;

public class JużZadeklarowana extends Exception{

    // Wyjątek, który jest używany, gdy zmienna została zadeklarowana kilkukrotnie.
    public JużZadeklarowana(String napis) {
        super(napis);
    }
}
