package Procedury;

import Błędy.IdentyczneNazwyParametrów;
import Błędy.Nieznaleziona;
import Instrukcje.*;
import Wyrażenia.Wyrażenie;
import Wyrażenia.Zmienna;

import java.util.ArrayList;
import java.util.List;

public class Procedura { // Procedury wiązą zmienne dynamicznie.
    private String nazwa; // Nazwa procedury.
    private Procedura[] procedury;
    private int ileprocedur;
    private Zmienna[] zmienne; // Zmienne, do których procedura ma dostęp.
    private int ilezmiennych; // Do ilu zmiennych procedura ma dostęp.
    private Zmienna[] parametry; // Parametry procedury.
    private Instrukcja[] treść; // Treść procedury.
    private Blok blokzadeklarowania; // Blok, w którym procedura została zadeklarowana.
    public boolean porównajNazwy(String druganazwa)
    {
        return this.nazwa.equals(druganazwa);
    }
    public int getBlokzadeklarowania()
    {
        return blokzadeklarowania.getZagnieżdżenie();
    }

    public Blok getBlok()
    {
        return blokzadeklarowania;
    }
    public Instrukcja[] getTreśćProcedury()
    {
        return treść;
    }

    public Zmienna[] getParametry()
    {
        return parametry;
    }

    public void setTreść(Instrukcja[] treść) // Ustawia procedurze treść.
    {
        this.treść = treść;
    }
    public int getIleProcedur()
    {
        return ileprocedur;
    }
    public String getNazwa()
    {
        return nazwa;
    }
    public Zmienna[] getZmienne()
    {
        return zmienne;
    }
    public int getIleZmiennych(){
        return ilezmiennych;
    }
    public Procedura[] getProcedury()
    {
        return procedury;
    }
    public Zmienna getZmienna(char nazwa) // Szuka w danej procedurze zmiennej o danej nazwie.
    {
        Zmienna cel = null;
        boolean znaleziona = false;
        int indeks = 0;

        while (!znaleziona && indeks < ilezmiennych) // Póki nieznaleziono.
        {
            if (zmienne[indeks].porównajNazwy(nazwa)) // Znaleziono!
            {
                znaleziona = true;
                cel = zmienne[indeks];
            }
            indeks++;
        }
        try { // Sprawdza, czy znaleziono zmienną o danej nazwie.
            if (cel == null) {
                throw new Nieznaleziona("W BLOKU O ZAGNIEŻDŻENIU " + getBlokzadeklarowania() + " NIE ISTNIEJE ZMIENNA O NAZWIE " +
                        String.valueOf(nazwa));
            }
        } catch (Nieznaleziona e) {
            System.out.println(e.getMessage());
            blokzadeklarowania.wypiszZmienne();
            System.exit(1);
        }
        return cel;
    }
    public Procedura getProcedura(String nazwa) // Szuka w danej procedurze zmiennej o danej nazwie.
    {
        Procedura cel = null;
        boolean znaleziona = false;
        int indeks = 0;
        while (!znaleziona && indeks < ileprocedur) // Póki nieznaleziono.
        {
            if (procedury[indeks].porównajNazwy(nazwa)) // Znaleziono!
            {
                znaleziona = true;
                cel = procedury[indeks];
            }
            indeks++;
        }
        try { // Sprawdza, czy znaleziono zmienną o danej nazwie.
            if (cel == null) {
                throw new Nieznaleziona("W BLOKU O ZAGNIEŻDŻENIU " + getBlokzadeklarowania() + " NIE ISTNIEJE PROCEDURA O NAZWIE " +
                        String.valueOf(nazwa));
            }
        } catch (Nieznaleziona e) {
            System.out.println(e.getMessage());
            blokzadeklarowania.wypiszZmienne();
            System.exit(1);
        }
        return cel;
    }
    @Override
    public String toString() { // Zwraca nazwę procedury.
        return nazwa;
    }
    public String toStringParametry() // Zwraca nazwę procedury wraz z jej parametrami.
    {
        String wypis = nazwa;
        for (int i = 0; i < parametry.length; i++)
        {
            wypis = wypis + "\nParametr numer " +  (i + 1) + ": " + parametry[i].getNazwa();
        }
        return wypis;
    }

    private void wyliczZmienne(Zmienna[] zmienne, char[] parametry, int ilezmiennych) // Zapisuje zmienne, do których ma dostęp.
    {
        this.parametry = new Zmienna[parametry.length]; // Zapisuje parametry (zmienne deklarowane w procedurze).
        for (int i = 0; i < parametry.length; i++)
        {
            this.parametry[i] = new Zmienna(parametry[i], 0, -1);
        }
        int indeks;
        boolean znalezione = false;
        for (int i = 0; i < parametry.length - 1; i++) { // Sprawdza, czy każdy parametr ma inną nazwę.
            for (indeks = i + 1; indeks < parametry.length; indeks++)
            {
                if(parametry[i] == parametry[indeks])
                {
                    znalezione = true;
                }
            }
        }
        try {
            if (znalezione) // Jeśli są parametry o takich samych nazwach.
            {
                throw new IdentyczneNazwyParametrów("PARAMETRY NIE MOGĄ MIEĆ TAKICH SAMYCH NAZW, A W PROCEDURZE O NAZWIE '" + nazwa + "' MAJĄ.");
            }
        }
        catch (IdentyczneNazwyParametrów e)
        {
            System.out.println(e.getMessage());
            blokzadeklarowania.wypiszZmienne();
            System.exit(1);
        }

        List<Zmienna> listazmiennych = new ArrayList<>(); // Zapisuje zmienne o nazwach innych, niż parametry.
        for (int i = 0; i < ilezmiennych; i++) // Szuka zmiennych o innych nazwach.
        {
            znalezione = false;
            indeks = 0;
            while (indeks < parametry.length && !znalezione)
            {
                if (zmienne[i].porównajNazwy(parametry[indeks]))
                {
                    znalezione = true;
                }
                indeks++;
            }
            if (!znalezione)
            {
                listazmiennych.add(zmienne[i]);
            }
        }
        this.ilezmiennych = listazmiennych.size() + parametry.length; // Zmienne o innych nazwach, niż parametry + paramety.
        this.zmienne = new Zmienna[this.ilezmiennych]; // Tablica wszystkich zmiennych.
        for (int i = 0; i < this.parametry.length; i++)
        {
            this.zmienne[i] = this.parametry[i];
        }
        for (int i = 0; i < listazmiennych.size(); i++) {
            this.zmienne[parametry.length + i] = listazmiennych.get(i);
        }
    }
    private void wyliczProcedury(Procedura[] procedury, int ileprocedur) {
        this.procedury = new Procedura[ileprocedur + 1];
        this.ileprocedur = ileprocedur;
        for (int i = 0; i < ileprocedur; i++) {
            this.procedury[i] = procedury[i];
        }
        this.procedury[ileprocedur] = this;
        this.ileprocedur++;

    }
    public void dodajProcedurę(Procedura procedura)
    {
        boolean wstawiona = false;
        for (int i = 0; i < ileprocedur; i++)
        {
            if (procedury[i].porównajNazwy(procedura.getNazwa()))
            {
                procedury[i] = procedura;
                wstawiona = true;
            }
        }
        if(!wstawiona && ileprocedur == procedury.length)
        {
            Procedura[] noweprocedury = new Procedura[ileprocedur * 2];
            for (int i = 0; i < ileprocedur; i++)
            {
                noweprocedury[i] = procedury[i];
            }
            noweprocedury[ileprocedur] = procedura;
            ileprocedur++;
            procedury = noweprocedury;
        }
    }
    public void dodajZmienną(char nazwa, Wyrażenie wyrażenie)
    {
        boolean wstawiona = false;
        for (int i = 0; i < ilezmiennych; i++)
        {
            if (zmienne[i].porównajNazwy(nazwa))
            {
                zmienne[i] = new Zmienna(nazwa, wyrażenie.getWartość(), -1);
                wstawiona = true;
            }
        }
        if(!wstawiona && ilezmiennych == zmienne.length)
        {
            Zmienna[] nowezmienne = new Zmienna[ilezmiennych * 2];
            for (int i = 0; i < ilezmiennych; i++)
            {
                nowezmienne[i] = zmienne[i];
            }
            nowezmienne[ilezmiennych] = new Zmienna(nazwa, wyrażenie.getWartość(), -1);
            ilezmiennych++;
            zmienne = nowezmienne;
        }
    }
    public Procedura(String nazwa, char[] parametry, Zmienna[] zmienne, int ilezmiennych, Blok blokzadeklarowania, Procedura[] procedury, int ileprocedur)
    {
        this.nazwa = nazwa;
        this.blokzadeklarowania = blokzadeklarowania;
        wyliczZmienne(zmienne, parametry, ilezmiennych);
        wyliczProcedury(procedury, ileprocedur);
    }

}
