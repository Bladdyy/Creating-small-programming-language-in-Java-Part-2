package Polecenia;

import Macchiato.Macchiato;

public class Step extends Polecenie {
    private int kroki;
    public void wykonajPolecenie()
    {
        if (kroki == 0 && !program.getPierwszyRuch()) // Jeśli nie zaczął się jeszcze program.
        {
            System.out.println("Następna instrukcja: blok numer 0 zaczyna się");
        }
        else {
            if (kroki > 0) { // Jeśli liczba z komendy jest poprawna.
                program.kolejneKroki(kroki);
            }
            if (!program.getKoniecProgramu()) { // Jeśli program się nie zakończył.
                program.getBloki()[program.getAktualnyBlok()].wypiszNastępnąInstrukcję();
            }
        }
    }
    public Step(int kroki, Macchiato program)
    {
        this.kroki = kroki;
        this.program = program;
    }
}