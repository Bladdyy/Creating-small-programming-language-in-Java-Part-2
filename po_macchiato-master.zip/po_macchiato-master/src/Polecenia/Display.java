package Polecenia;
import Macchiato.Macchiato;
import Wyrażenia.*;
public class Display extends Polecenie {
    private int poziom;
    public String stwórzKomunikat()
    {
        String komunikat;
        if (poziom == -1 || program.getAktualnyBlok() < poziom) // Jeśli liczba nie spełnia kryteriów.
        {
            komunikat = "Nie istenieje blok na tym poziomie wartościowania. " +
                    "Maksymalne wartościowanie to " + program.getAktualnyBlok();
        } else {
            komunikat = "Aktualne wartościowanie z poziomu: " + poziom + "\n"+
                    "Można wziąc wartościowanie jeszcze z bloków maksymalnie większych o " +
                    (program.getAktualnyBlok() - poziom) + "\n\n" + "Wartości zmiennych na tym poziomie:\n";

            Zmienna[] zmienne = program.getBloki()[poziom].getZmienne();
            int ilezmiennych = program.getBloki()[poziom].getIleZmiennych();
            for (int i = 0; i < ilezmiennych; i++) { // Wypisuje zmienne z danego poziomu.
                if (zmienne[i].getBlokzadeklarowania() == poziom) {
                    komunikat = komunikat + (i+1) + ". Zmienna o nazwie " + zmienne[i].getNazwa() + " ma wartość " +
                            zmienne[i].getWartość() + "\n";
                }
            }
        }
        return komunikat;
    }
    public void wykonajPolecenie()
    {
        System.out.println(stwórzKomunikat());
    }
    public Display(int poziom, Macchiato program)
    {
        this.poziom = poziom;
        this.program = program;
    }
}
