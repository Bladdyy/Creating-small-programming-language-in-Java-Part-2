package Polecenia;

import Macchiato.Macchiato;
import Procedury.Procedura;
import java.io.FileWriter;
import java.io.IOException;


public class Dump extends Polecenie {
    String ścieżka;
    public void wykonajPolecenie(){
        try {
            FileWriter plik = new FileWriter(ścieżka);
            // Dopisz procedury.
            Procedura[] procedury = program.getBloki()[program.getAktualnyBlok()].getProcedury();
            int ileprocedur = program.getBloki()[program.getAktualnyBlok()].getIleprocedur();
            String komunikatprocedur;
            if (ileprocedur == 0)
            {
                komunikatprocedur = "Nie ma aktualnie zadeklarowanych procedur. \n";
            }
            else {
                komunikatprocedur = "Aktualnie zadeklarowane procedury:\n";
                for (int i = 0; i < ileprocedur; i++) {
                    komunikatprocedur = komunikatprocedur + "\n" + (i+1) + ". " + procedury[i].toStringParametry() + "\n";
                }
            }
            komunikatprocedur = komunikatprocedur + "\n" + new Display(0, program).stwórzKomunikat();
            plik.write(komunikatprocedur);
            plik.close();
        }
        catch (IOException e)
        {
            System.out.println(e.getMessage());
        }
    }
    public Dump(String ścieżka, Macchiato program)
    {
        this.ścieżka = ścieżka;
        this.program = program;
    }
}
