package Polecenia;

import Macchiato.Macchiato;
public class Exit extends Polecenie {
    public void wykonajPolecenie()
    {
        program.setKoniecProgramu(true);
    }
    public Exit(Macchiato program)
    {
        this.program = program;
    }
}
