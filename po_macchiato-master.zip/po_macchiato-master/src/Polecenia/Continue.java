package Polecenia;
import Macchiato.Macchiato;

public class Continue extends Polecenie {

    public void wykonajPolecenie()
    {
        program.kolejneKroki(-1);
    }
    public Continue(Macchiato program)
    {
        this.program = program;
    }
}
