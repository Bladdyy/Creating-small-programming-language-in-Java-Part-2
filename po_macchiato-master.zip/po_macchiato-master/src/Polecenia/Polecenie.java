package Polecenia;
import Macchiato.Macchiato;

public abstract class Polecenie {
    protected Macchiato program;
    public abstract void wykonajPolecenie();

}
