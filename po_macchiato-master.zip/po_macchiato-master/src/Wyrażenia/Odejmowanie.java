package Wyrażenia;

import Błędy.DzieleniePrzezZero;

public class Odejmowanie extends Dwuargumentowe {
    private Wyrażenie wyrażenie1; // Wyrażenia.Wyrażenie, od którego odejmujemy.
    private Wyrażenie wyrażenie2; // Wyrażenia.Wyrażenie odejmowane.
    public void liczWartość() throws DzieleniePrzezZero
    {
        wartość = wyrażenie1.getWartość() - wyrażenie2.getWartość();
    }
    public static Odejmowanie odejmij(Wyrażenie wyrażenie1, Wyrażenie wyrażenie2)
    {
        return new Odejmowanie(wyrażenie1, wyrażenie2);
    }
    public String toString()
    {
        return "(" + wyrażenie1.toString() + " - " + wyrażenie2.toString() + ")";
    }
    public Odejmowanie(Wyrażenie wyrażenie1, Wyrażenie wyrażenie2)
    {
        this.wyrażenie1 = wyrażenie1;
        this.wyrażenie2 = wyrażenie2;
    }

}
