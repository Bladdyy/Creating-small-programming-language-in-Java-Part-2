package Wyrażenia;

import Błędy.DzieleniePrzezZero;

public abstract class Wyrażenie {
    protected int wartość; // Wartość liczbowa wyrażenia.

    public int getWartość() throws DzieleniePrzezZero
    {
        return wartość;
    }

    public abstract String toString();
}
