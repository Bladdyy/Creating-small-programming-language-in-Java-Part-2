package Wyrażenia;

import Błędy.DzieleniePrzezZero;

public class Modulo extends Dwuargumentowe {
    private Wyrażenie wyrażenie1; // Wyrażenia.Wyrażenie dzielone.
    private Wyrażenie wyrażenie2; // Wyrażenia.Wyrażenie będące dzielnikiem.
    public void liczWartość() throws DzieleniePrzezZero {
        if (wyrażenie2.getWartość() == 0) {
            throw new DzieleniePrzezZero("NIE WOLNO DZIELIĆ PRZEZ ZERO!");
        }
        else { // Jeśli nie ma, to dzielimy
            wartość = wyrażenie1.getWartość() % wyrażenie2.getWartość();
        }
    }
    public static Modulo moduluj(Wyrażenie wyrażenie1, Wyrażenie wyrażenie2)
    {
        return new Modulo(wyrażenie1, wyrażenie2);
    }
    public String toString()
    {
        return "(" + wyrażenie1.toString() + " % " + wyrażenie2.toString() + ")";
    }

    public Modulo(Wyrażenie wyrażenie1, Wyrażenie wyrażenie2)
    {
        this.wyrażenie1 = wyrażenie1;
        this.wyrażenie2 = wyrażenie2;
    }

}
