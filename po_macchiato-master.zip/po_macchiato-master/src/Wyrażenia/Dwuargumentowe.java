package Wyrażenia;


import Błędy.DzieleniePrzezZero;

public abstract class Dwuargumentowe extends Wyrażenie {
    public abstract void liczWartość() throws DzieleniePrzezZero; // Oblicza wartość danego wyrażenia.
    @Override
    public int getWartość() throws DzieleniePrzezZero
    {
        liczWartość();
        return wartość;
    }
}
