package Wyrażenia;

public class Literał extends Wyrażenie {
    public String toString()
    {
        return Integer.toString(getWartość());
    }
    public static Literał wartość(int wartość)
    {
        return new Literał(wartość);
    }
    public Literał(int wartość)
    {
        this.wartość = wartość;
    }
}
