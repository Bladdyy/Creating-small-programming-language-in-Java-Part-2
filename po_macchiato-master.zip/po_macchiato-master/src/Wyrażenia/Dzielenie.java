package Wyrażenia;
import Błędy.DzieleniePrzezZero;
public class Dzielenie extends Dwuargumentowe {
    private Wyrażenie wyrażenie1; // Wyrażenia.Wyrażenie dzielone.
    private Wyrażenie wyrażenie2; // Wyrażenia.Wyrażenie będące dzielnikiem.

    public void liczWartość() throws DzieleniePrzezZero
    {
        if (wyrażenie2.getWartość() == 0) { // Sprawdza, czy nie ma dzielenia przez zero.
            throw new DzieleniePrzezZero("NIE WOLNO DZIELIĆ PRZEZ ZERO!");
        }
        else {
            wartość = wyrażenie1.getWartość() / wyrażenie2.getWartość();
        }
    }
    public static Dzielenie podziel(Wyrażenie wyrażenie1, Wyrażenie wyrażenie2)
    {
        return new Dzielenie(wyrażenie1, wyrażenie2);
    }
    public String toString()
    {
        return "(" + wyrażenie1.toString() + " / " + wyrażenie2.toString() + ")";
    }

    public Dzielenie(Wyrażenie wyrażenie1, Wyrażenie wyrażenie2)
    {
        this.wyrażenie1 = wyrażenie1;
        this.wyrażenie2 = wyrażenie2;
    }
}
