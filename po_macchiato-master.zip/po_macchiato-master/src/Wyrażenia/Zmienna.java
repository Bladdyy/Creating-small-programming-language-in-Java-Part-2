package Wyrażenia;

import Wyrażenia.Wyrażenie;

public class Zmienna extends Wyrażenie {
    private char nazwa; // Nazwa zmiennej.
    private int blokzadeklarowania; // Zagnieżdżenie, w którym została zadeklarowana.
    public boolean porównajNazwy(char nazwa) // Porównuje nazwę tej zmiennej z 'nazwa'.
    {
        if(nazwa == this.nazwa)
        {
            return true;
        }
        return false;
    }
    public String toString()
    {
        return String.valueOf(nazwa);
    }
    public void setWartość(int nowawartość)
    {
        wartość = nowawartość;
    }
    public int getBlokzadeklarowania()
    {
        return blokzadeklarowania;
    }
    public char getNazwa() { return nazwa; }
    public Zmienna(char nazwa, int wartość, int któryblok)
    {
        this.wartość = wartość;
        this.nazwa = nazwa;
        this.blokzadeklarowania = któryblok;
    }
}
