package Wyrażenia;
import Błędy.DzieleniePrzezZero;
public class Dodawanie extends Dwuargumentowe {
    private Wyrażenie wyrażenie1; // Wyrażenia.Wyrażenie, do którego dodajemy.
    private Wyrażenie wyrażenie2; // Wyrażenia.Wyrażenie dodawane.
    public void liczWartość() throws DzieleniePrzezZero
    {
        wartość = wyrażenie1.getWartość() + wyrażenie2.getWartość();
    }
    public String toString()
    {
        return "(" + wyrażenie1.toString() + " + " + wyrażenie2.toString() + ")";
    }

    public static Dodawanie dodaj(Wyrażenie wyrażenie1, Wyrażenie wyrażenie2)
    {
        return new Dodawanie(wyrażenie1, wyrażenie2);
    }
    public Dodawanie(Wyrażenie wyrażenie1, Wyrażenie wyrażenie2)
    {
        this.wyrażenie1 = wyrażenie1;
        this.wyrażenie2 = wyrażenie2;
    }
}
