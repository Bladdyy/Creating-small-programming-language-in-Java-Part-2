package Wyrażenia;

import Błędy.DzieleniePrzezZero;

public class Mnożenie extends Dwuargumentowe {
    private Wyrażenie wyrażenie1; // Wyrażenia.Wyrażenie mnożone.
    private Wyrażenie wyrażenie2; // Wyrażenia.Wyrażenie, przez które mnożmy.
    public void liczWartość() throws DzieleniePrzezZero
    {
        wartość = wyrażenie1.getWartość() * wyrażenie2.getWartość();
    }
    public static Mnożenie pomnóż(Wyrażenie wyrażenie1, Wyrażenie wyrażenie2)
    {
        return new Mnożenie(wyrażenie1, wyrażenie2);
    }
    public String toString()
    {
        return "(" + wyrażenie1.toString() + " * " + wyrażenie2.toString() + ")";
    }

    public Mnożenie(Wyrażenie wyrażenie1, Wyrażenie wyrażenie2)
    {
        this.wyrażenie1 = wyrażenie1;
        this.wyrażenie2 = wyrażenie2;
    }
}
