package Instrukcje;

import Błędy.DzieleniePrzezZero;
import Wyrażenia.*;

public class InstrukcjaWarunkowa extends Instrukcja{
    private Wyrażenie wyrażenie1; // Pierwsze porównywane wyrażenie.
    private Wyrażenie wyrażenie2; // Drugie porównywane wyrażenie.
    private String symbol; // Symbol porównywania.
    private Instrukcja instrukcja1; // Instrukcje.Instrukcja wykonywana, jeśli porównanie jest prawdziwe.
    private Instrukcja instrukcja2 = null; // Instrukcje.Instrukcja wykonywana w przeciwnym razie.
    private Blok blok; // Instrukcje.Blok, do którego dodawana jest instrukcja.
    public void wykonujInstrukcję() throws DzieleniePrzezZero// Wykonuje if'a, poczym jeśli trzeba dodaje nową instrukcję do bloku.
    {
        int wartość1 = wyrażenie1.getWartość();
        int wartość2 = wyrażenie2.getWartość();
        if (symbol == "=" && wartość1 == wartość2)
        {
            blok.dodajInstrukcjęOdWarunkowej(instrukcja1);
        }
        else if(symbol == "=" && instrukcja2 != null)
        {
            blok.dodajInstrukcjęOdWarunkowej(instrukcja2);
        }
        else if (symbol == "<>" && wartość1 != wartość2)
        {
            blok.dodajInstrukcjęOdWarunkowej(instrukcja1);
        }
        else if(symbol == "<>" && instrukcja2 != null)
        {
            blok.dodajInstrukcjęOdWarunkowej(instrukcja2);
        }
        else if (symbol == "<" && wartość1 < wartość2)
        {
            blok.dodajInstrukcjęOdWarunkowej(instrukcja1);
        }
        else if(symbol == "<" && instrukcja2 != null)
        {
            blok.dodajInstrukcjęOdWarunkowej(instrukcja2);
        }
        else if (symbol == ">" && wartość1 > wartość2)
        {
            blok.dodajInstrukcjęOdWarunkowej(instrukcja1);
        }
        else if(symbol == ">" && instrukcja2 != null)
        {
            blok.dodajInstrukcjęOdWarunkowej(instrukcja2);
        }
        else if (symbol == "<=" && wartość1 <= wartość2)
        {
            blok.dodajInstrukcjęOdWarunkowej(instrukcja1);
        }
        else if(symbol == "<=" && instrukcja2 != null)
        {
            blok.dodajInstrukcjęOdWarunkowej(instrukcja2);
        }
        else if (symbol == ">=" && wartość1 >= wartość2)
        {
            blok.dodajInstrukcjęOdWarunkowej(instrukcja1);
        }
        else if(symbol == ">=" && instrukcja2 != null)
        {
            blok.dodajInstrukcjęOdWarunkowej(instrukcja2);
        }
    }

    public String toString()
    {
        return "Następne polecenie: Instrukcja warunkowa " + wyrażenie1.toString() + " " +
                symbol + " " + wyrażenie2.toString();
    }

    // Jeśli nie ma else.
    public InstrukcjaWarunkowa(Wyrażenie wyrażenie1, String symbol, Wyrażenie wyrażenie2,
                               Instrukcja instrukcja, Blok blok)
    {
        this.wyrażenie1 = wyrażenie1;
        this.wyrażenie2 = wyrażenie2;
        this.symbol = symbol;
        this.instrukcja1 = instrukcja;
        this.blok = blok;
    }

    // Jeśli jest else.
    public InstrukcjaWarunkowa(Wyrażenie wyrażenie1, String symbol, Wyrażenie wyrażenie2,
                               Instrukcja instrukcja1, Instrukcja instrukcja2, Blok blok)
    {
        this.wyrażenie1 = wyrażenie1;
        this.wyrażenie2 = wyrażenie2;
        this.symbol = symbol;
        this.instrukcja1 = instrukcja1;
        this.instrukcja2 = instrukcja2;
        this.blok = blok;
    }
}
