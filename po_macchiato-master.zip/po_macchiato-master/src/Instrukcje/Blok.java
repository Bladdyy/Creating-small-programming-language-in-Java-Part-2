package Instrukcje;

import Błędy.*;
import Wyrażenia.*;
import Macchiato.Macchiato;
import Procedury.Procedura;

public class Blok extends Instrukcja{
    private boolean pierwszyraz = true;
    public boolean skończonyblok = false;

    private Procedura[] procedury = new Procedura[2]; // Procedury widniejące w danym bloku.
    private int ileprocedur = 0; // Ile jest procedur w danym bloku.
    private int gdzieprocedura = -1; // Zapamiętuje kolejne indeksy procedur zadeklarowanych w danym bloku.
    private int aktualnaprocedura = 0; // Aktualnie deklarowana procedura.
    private int iledeklaracjiprocedur = 0; // Ile zadeklarowano procedur w danym bloku.

    private Zmienna[] zmienne = new Zmienna[2]; // Zmienne w danym bloku.
    private int ilezmiennych = 0; // Ile zmiennych w bloku.

    private Zmienna[] deklaracje = new Zmienna[2]; // Nowodeklarowane zmienne.
    private int iledeklaracji = 0; // Ile świeżo zadeklarowanych zmiennych.
    private int aktualnadeklaracja = 0; // Którą deklarację wypisujemy.

    private Instrukcja[] instrukcje = new Instrukcja[2]; // Instrukcje do wykonania w tym bloku.
    private int ileinstrukcji = 0; // Ile instukcji blok ma do wykonania.
    private Instrukcja[] fabryczneinstrukcje; // Początkowe instrukcje.
    private int fabryczneileinstrukcji; // Liczba instrukcji fabrycznych.
    private int aktualnainstrukcja = 0; // Którą instrukcję wykonuje.
    private boolean pierwszeprzejście = true; // Czy ten blok jest rozpatrywany pierwszy raz.
    private int zagnieżdżenie; // Poziom zagnieżdżenia tego bloku.
    private Macchiato macchiato; // Program, w którym blok się znajduje.
    private boolean aktywacja = false; // Czy włączył się.
    public void deklaracjaProcedury(String nazwa, char[] parametry) // Deklaruje nową procedurę.
    {
        boolean zadeklarowana = false;
        for (int i = 0; i < ileprocedur; i++) { // Sprawdza, czy nie ma procedury o tej samej nazwie.

            if (procedury[i].porównajNazwy(nazwa)) { // Jest procedura o takiej samej nazwie!
                // Została w tym bloku zadeklarowana procedura o tej nazwie.
                try {
                    if (zagnieżdżenie == procedury[i].getBlokzadeklarowania()) {
                        throw new JużZadeklarowana("PROCEDURY O TEJ SAMEJ NAZWIE NIE MOGĄ BYĆ DEKLAROWANE KILKUKROTNIE W JEDNYM " +
                                "BLOKU, A PROCEDURA O NAZWIE " + String.valueOf(nazwa) + " JEST ZADEKLAROWANA W TYM BLOKU.");
                    } else // Jest procedura o takiej nazwie z innego bloku.
                    {
                        procedury[i] = new Procedura(nazwa, parametry, zmienne, ilezmiennych, this, this.getProcedury(), this.ileprocedur); // Nadpisuje procedurę o tej nazwie.
                        iledeklaracjiprocedur++;
                    }
                }
                catch (JużZadeklarowana e) {
                    System.out.println(e.getMessage());
                    wypiszZmienne();
                    System.exit(1);
                }
                zadeklarowana = true;
            }
        }
        if (!zadeklarowana) { // Nowa procedura jest deklarowana!
            dodajProcedurę(nazwa, parametry); // Dodaje procedurę do listy procedur.
            iledeklaracjiprocedur++;
        }
    }
    private void dodajProcedurę(String nazwa, char[] parametry) // Dodaje świeżą procedurę.
    {
        if (ileprocedur == procedury.length) // Jeśli tablica zmiennych jest pełna, to poszerza ją dwukrotnie.
        {
            Procedura[] nowatablicaprocedur = new Procedura[procedury.length * 2];
            for (int i = 0; i < ileprocedur; i++) {
                nowatablicaprocedur[i] = procedury[i];
            }
            procedury = nowatablicaprocedur;
        }
        procedury[ileprocedur] = new Procedura(nazwa, parametry, zmienne, ilezmiennych, this, this.getProcedury(), this.ileprocedur);
        ileprocedur++;
    }
    public Procedura getProcedura(String nazwa) // Szuka w bloku procedury o danej nazwie.
    {
        Procedura cel = null;
        boolean znaleziona = false;
        int indeks = 0;
        while(!znaleziona && indeks < ileprocedur) // Póki nieznaleziono.
        {
            if (procedury[indeks].porównajNazwy(nazwa)) // Znaleziono!
            {
                znaleziona = true;
                cel = procedury[indeks];
            }
            indeks++;
        }
        try{ // Sprawdza, czy znaleziono procedurę o danej nazwie.
            if (cel == null)
            {
                throw new Nieznaleziona("W BLOKU O ZAGNIEŻDŻENIU " + zagnieżdżenie + " NIE ISTNIEJE PROCEDURA O NAZWIE " +
                        String.valueOf(nazwa));
            }
        }
        catch (Nieznaleziona e){
            System.out.println(e.getMessage());
            wypiszZmienne();
            System.exit(1);
        }
        return cel;
    }
    public void deklaracjaZmiennej(char nazwa, Wyrażenie wyrażenie) // Deklaruje nową zmienną.
    {
        int wartośćzmiennej = 0;
        try {
            wartośćzmiennej = wyrażenie.getWartość();
        } catch (DzieleniePrzezZero e) {
            System.out.println(e.getMessage());
            System.out.println("Błąd przy deklaracji zmiennej o nazwie " + nazwa);
            wypiszZmienne();
            System.exit(1);
        }
        boolean zadeklarowana = false;
        for (int i = 0; i < ilezmiennych; i++) { // Sprawdza, czy nie ma zmiennej o tej samej nazwie.

            if (zmienne[i].porównajNazwy(nazwa)) { // Jest zmienna o takiej samej nazwie!
                // Została w tym bloku zadeklarowana zmienna o tej nazwie.
                try {
                    if (zagnieżdżenie == zmienne[i].getBlokzadeklarowania()) {
                        throw new JużZadeklarowana("ZMIENNE NIE MOGĄ BYĆ DEKLAROWANE KILKUKROTNIE W JEDNYM " +
                                "BLOKU, A ZMIENNA O NAZWIE " + String.valueOf(nazwa) + " JEST.");
                    } else // Jest zmienna o takiej nazwie z innego bloku.
                    {
                        zmienne[i] = new Zmienna(nazwa, wartośćzmiennej, this.zagnieżdżenie); // Nadpisuje zmienną.
                        dodajDeklaracje(nazwa, wartośćzmiennej); // Dodaje do listy zadeklarowanych zmiennych.
                    }
                }
                catch (JużZadeklarowana e) {
                    System.out.println(e.getMessage());
                    wypiszZmienne();
                    System.exit(1);
                }
                zadeklarowana = true;
            }
        }
        if (!zadeklarowana) { // Nowa zmienna jest deklarowana!
            dodajZmienną(nazwa, wartośćzmiennej); // Dodaje zmienną do listy zmiennych.
            dodajDeklaracje(nazwa, wartośćzmiennej); // Zapisuje, że została zadeklarowana.
        }
    }
    private void dodajDeklaracje(char nazwa, int wyrażenie) // Dodaje zmienną zadeklarowaną w tym bloku.
    {
        if (iledeklaracji == deklaracje.length) // Wydłużanie tablicy świeżododanych zmiennych.
        {
            Zmienna[] nowatablicazmiennych = new Zmienna[deklaracje.length * 2];
            for (int i = 0; i < iledeklaracji; i++) {
                nowatablicazmiennych[i] = deklaracje[i];
            }
            deklaracje = nowatablicazmiennych;
        }
        deklaracje[iledeklaracji] = new Zmienna(nazwa, wyrażenie, this.getZagnieżdżenie());
        iledeklaracji++;
    }
    private void dodajZmienną(char nazwa, int wyrażenie) // Dodaje świeżo zadeklarowaną zmienną.
    {
        if (ilezmiennych == zmienne.length) // Jeśli tablica zmiennych jest pełna.
        {
            Zmienna[] nowatablicazmiennych = new Zmienna[zmienne.length * 2];
            for (int i = 0; i < ilezmiennych; i++) {
                nowatablicazmiennych[i] = zmienne[i];
            }
            zmienne = nowatablicazmiennych;
        }
        zmienne[ilezmiennych] = new Zmienna(nazwa, wyrażenie, this.getZagnieżdżenie());
        ilezmiennych++;
    }
    public Zmienna getZmienna(char nazwa) // Szuka w bloku zmiennej o danej nazwie.
    {
        Zmienna cel = null;
        boolean znaleziona = false;
        int indeks = 0;
        while(!znaleziona && indeks < ilezmiennych) // Póki nieznaleziono.
        {
            if (zmienne[indeks].getNazwa() == nazwa) // Znaleziono!
            {
                znaleziona = true;
                cel = zmienne[indeks];
            }
            indeks++;
        }
        try{ // Sprawdza, czy znaleziono zmienną o danej nazwie.
            if (cel == null)
            {
                throw new Nieznaleziona("W BLOKU O ZAGNIEŻDŻENIU " + zagnieżdżenie + " NIE ISTNIEJE ZMIENNA O NAZWIE " +
                        String.valueOf(nazwa));
            }
        }
        catch (Nieznaleziona e){
            System.out.println(e.getMessage());
            wypiszZmienne();
            System.exit(1);
        }
        return cel;
    }
    public void wypiszZmienne() // Wypisuje zmienne zadeklarowane w danym bloku.
    {
        if (ilezmiennych != 0) { // Jeśli są jakieś zmienne.
            System.out.println("Aktualne wartości zmiennych to");
            for (int i = 0; i < ilezmiennych; i++) {
                System.out.println(zmienne[i] + " o wartości " + zmienne[i].getWartość());
            }
        }
        else
        {
            System.out.println("Brak zmiennych w tym bloku");
        }
    }
    public void wypiszNastępnąInstrukcję() // Wypisuje następną instrukcję.
    {
        macchiato.getBloki()[zagnieżdżenie] = this;
        if (!aktywacja) // Otwieranie bloku.
        {
            System.out.println("Następna instrukcja: blok numer " + macchiato.getAktualnyBlok() + " zaczyna się");
        }
        else if (iledeklaracji > aktualnadeklaracja) // Kolejne deklaracje zmiennych.
        {
            System.out.println("Następna instrukcja: Deklarowanie zmiennej " + deklaracje[aktualnadeklaracja]);
        }
        else if (iledeklaracjiprocedur > aktualnaprocedura) // Kolejne deklaracje procedur.
        {
            boolean znaleziona = false;
            while (!znaleziona && gdzieprocedura + 1 < ileprocedur)
            {
                gdzieprocedura++;
                if (procedury[gdzieprocedura].getBlokzadeklarowania() == zagnieżdżenie)
                {
                    znaleziona = true;
                }
            }
            System.out.println("Następna instrukcja: Deklarowanie procedury o nazwie " + procedury[gdzieprocedura]);
        }
        else if (aktualnainstrukcja == ileinstrukcji && iledeklaracji == aktualnadeklaracja) { // Koniec bloku.
            System.out.println("Następna instrukcja: blok numer: " + macchiato.getAktualnyBlok() + " kończy się");
        }
        else // Jeśli żaden z poprzednich przypadków, to wykonują się jeszcze instrukcje.
        {
            System.out.println("Następna instrukcja: " + instrukcje[aktualnainstrukcja].toString());
        }
    }

    public void dodajInstrukcję(Instrukcja instrukcja) // Dodaje instrukcję do tablicy instrukcji do wykonania.
    {
        if (ileinstrukcji == instrukcje.length) // Wydłużanie tablicy.
        {
            Instrukcja[] nowatablicazmiennych = new Instrukcja[instrukcje.length * 2];
            for (int i = 0; i < ileinstrukcji; i++) {
                nowatablicazmiennych[i] = instrukcje[i];
            }
            instrukcje = nowatablicazmiennych;
        }
        instrukcje[ileinstrukcji] = instrukcja;
        ileinstrukcji++;
    }
    public void dodajInstrukcjeProcedury(Instrukcja[] treśćprocedury, Instrukcja koniecprocedury) // Dodaje instrukcje otrzymane od procedury.
    {
        Instrukcja[] noweinstrukcje = new Instrukcja[treśćprocedury.length +
                ileinstrukcji - aktualnainstrukcja]; // Tworzy nową tablicę instrukcji.
        for (int i = 0; i < treśćprocedury.length; i++) // Wpisuje do nowej tablicy instrukcji nowe instrukcje od procedury.
        {
            noweinstrukcje[i] = treśćprocedury[i];
        }
        noweinstrukcje[treśćprocedury.length] = koniecprocedury;

        // Przepisuje na koniec niewykonane dotąd instrukcje, które miały wykonać się po procedurze.
        for (int i = 0; i < ileinstrukcji - aktualnainstrukcja - 1; i++)
        {
            noweinstrukcje[treśćprocedury.length + i + 1] = instrukcje[aktualnainstrukcja + 1 + i];
        }
        instrukcje = noweinstrukcje; // Nadpisuje instrukcje nowymi.
        ileinstrukcji = treśćprocedury.length + ileinstrukcji - aktualnainstrukcja;
        aktualnainstrukcja = -1;
    }
    public void dodajInstrukcjęOdWarunkowej(Instrukcja instrukcja) // Dodaje instrukcję otrzymaną od instrukcji warunkowej.
    {
        instrukcje[aktualnainstrukcja] = instrukcja;
        aktualnainstrukcja--;
    }

    // Dodaje instrukcje otrzymane od pętli.
    public void dodajInstrukcjeOdPętli(Instrukcja[] instrukcjezpętli)
    {
        Instrukcja[] noweinstrukcje = new Instrukcja[instrukcjezpętli.length +
                ileinstrukcji - aktualnainstrukcja - 1]; // Tworzy nową tablicę instrukcji.
        for (int i = 0; i < instrukcjezpętli.length; i++) // Wpisuje do nowej tablicy instrukcji nowe instrukcje od pętli.
        {
            noweinstrukcje[i] = instrukcjezpętli[i];
        }
        // Przepisuje na koniec niewykonane dotąd instrukcje, które miały wykonać się po pętli.
        for (int i = 0; i < ileinstrukcji - aktualnainstrukcja - 1; i++)
        {
            noweinstrukcje[instrukcjezpętli.length + i] = instrukcje[aktualnainstrukcja + 1 + i];
        }
        instrukcje = noweinstrukcje; // Nadpisuje instrukcje nowymi.
        ileinstrukcji = instrukcjezpętli.length + ileinstrukcji - aktualnainstrukcja - 1;
        aktualnainstrukcja = -1;
    }
    private void resetujBlok() // Przywraca blokowi bazowe parametry.
    {
        aktywacja = false;
        aktualnadeklaracja = 0;
        aktualnainstrukcja = 0;
        aktualnaprocedura = 0;
        instrukcje = new Instrukcja[fabryczneileinstrukcji];
        for (int i = 0; i < fabryczneileinstrukcji; i++) {
            instrukcje[i] = fabryczneinstrukcje[i];
        }
        ileinstrukcji = fabryczneileinstrukcji;
        // Przywraca deklaracjom z tego bloku ich pierwotne wartości.
        for (int i = 0; i < ilezmiennych; i++)
        {
            // Jeśli zmienna została zadeklarowana w tym bloku.
            if (zmienne[i].getBlokzadeklarowania() == zagnieżdżenie)
            {
                boolean znaleziona = false;
                int indeks = 0;
                while (!znaleziona)
                {
                    // Jeśli to zmienna o takiej nazwie.
                    if (zmienne[i].porównajNazwy(deklaracje[indeks].getNazwa()))
                    {
                        zmienne[i].setWartość(deklaracje[indeks].getWartość());
                        znaleziona = true;
                    }
                    indeks++;
                }
            }
        }
    }


    // Wykonuje kolejną instrukcję w bloku.
    public void wykonujInstrukcję() {
        if (!aktywacja) { // Aktywacja bloku
            if (pierwszyraz) // Zapisuje pierwszą wersję instrukcji.
            {
                fabryczneinstrukcje = new Instrukcja[ileinstrukcji];
                for (int i = 0; i < ileinstrukcji; i++)
                {
                    fabryczneinstrukcje[i] = instrukcje[i];
                }
                fabryczneileinstrukcji = ileinstrukcji;
                pierwszyraz = false;
            }
            macchiato.dodajBlok(this); // Dodaje blok do tablicy bloków.
            macchiato.zwiększAktualnyBlok(); // Zwiększa aktualnie rozpatrywany blok
            aktywacja = true;
        }
        else if (iledeklaracji > aktualnadeklaracja) // Deklaruje kolejno nowe zmienne.
        {
            aktualnadeklaracja++;
        }
        else if (iledeklaracjiprocedur > aktualnaprocedura) // Deklaruje kolejno nowe procedury.
        {
            aktualnaprocedura++;
        }
        // Jeśli zadeklarował wszystkie zmienne i wykonał wszystkie instrukcje.
        else if (aktualnainstrukcja == ileinstrukcji && iledeklaracji == aktualnadeklaracja && aktualnaprocedura == iledeklaracjiprocedur)
        {
            macchiato.skończAktualnyBlok(); // Instrukcje.Blok się kończy.
            resetujBlok(); // Przywraca bazowe wartości w bloku.
            skończonyblok = true;
        }
        // Jeśli wszystkie zmienne zostały zadeklarowane i blok ma do wykonania instrukcje.
        else {
            try {
                instrukcje[aktualnainstrukcja].wykonujInstrukcję(); // Wykonuje kolejną instrukcję.
            }
            catch (DzieleniePrzezZero e)
            {
                System.out.println(e.getMessage());
                System.out.println("Błąd w " + instrukcje[aktualnainstrukcja]);
                if (ilezmiennych != 0) {
                    System.out.println("Aktualne wartości zmiennych to");
                    for (int i = 0; i < ilezmiennych; i++) {
                        System.out.println(zmienne[i] + " o wartości " + zmienne[i].getWartość());
                    }
                }
                else
                {
                    System.out.println("Brak zmiennych w tym bloku");
                }
                System.exit(1);
            }
            aktualnainstrukcja++;
        }
        if (macchiato.getWykonwyaneProcedury() > 0) // Jeśli program jest w trakcie wykonywania procedury.
        {
            wykonujInstrukcję(); // Wykonuje wszystkie instrukcje procedury od razu.
        }
    }

    public int getIleZmiennych()
    {
        return ilezmiennych;
    }
    public Zmienna[] getZmienne()
    {
        return zmienne;
    }
    public Procedura[] getProcedury()
    {
        return procedury;
    }
    public int getIleprocedur()
    {
        return ileprocedur;
    }
    public int getZagnieżdżenie()
    {
        return zagnieżdżenie;
    }
    public String toString()
    {
        return "Następne polecenie: Nowy Blok o zagnieżdżeniu " + Integer.toString(zagnieżdżenie);
    }



    public Blok(Macchiato macchiato){
        this.zagnieżdżenie = macchiato.getZagnieżdżenie() + 1;
        this.macchiato = macchiato;
        if (zagnieżdżenie > 0) // Bierze zmienne od poprzedniego bloku.
        {
            ilezmiennych = macchiato.getBloki()[zagnieżdżenie - 1].getIleZmiennych();
            zmienne = new Zmienna[ilezmiennych];
            Zmienna[] dodawane = macchiato.getBloki()[zagnieżdżenie - 1].getZmienne();
            for (int i = 0; i < ilezmiennych; i++) {
                zmienne[i] = dodawane[i];
            }
            ileprocedur = macchiato.getBloki()[zagnieżdżenie - 1].getIleprocedur();
            procedury = new Procedura[ileprocedur];
            Procedura[] dodawaneprocedury = macchiato.getBloki()[zagnieżdżenie - 1].getProcedury();
            for (int i = 0; i < ileprocedur; i++) {
                procedury[i] = dodawaneprocedury[i];
            }

        }
        macchiato.dodajBlok(this); // Dodaje blok do tablicy aktualnych bloków.
    }
}

