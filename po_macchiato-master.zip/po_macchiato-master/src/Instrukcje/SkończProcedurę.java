package Instrukcje;

import Błędy.DzieleniePrzezZero;
import Macchiato.Macchiato;
import Procedury.Procedura;
import Wyrażenia.Zmienna;

public class SkończProcedurę extends Instrukcja {
    private Macchiato program;
    private Procedura procedura; // Procedura, którą kończy.
    private int[] wartości; // Wartości parametrów procedury sprzed wykonania bloku.
    public void wykonujInstrukcję() throws DzieleniePrzezZero
    {
        program.skończonaProcedura(); // Kończy procedurę.
        Zmienna[] parametry = procedura.getParametry();
        for (int i = 0; i < parametry.length; i++)
        {
            parametry[i].setWartość(wartości[i]); // Ustawia parametrom procedury z powrotem ich poprzednie wartości.
        }
    }
    public String toString()
    {
        return "Koniec Procedury.";
    };
    public SkończProcedurę(Procedura procedura, Macchiato program, int[] wartości)
    {
        this.procedura = procedura;
        this.wartości = wartości;
        this.program = program;
    }
}
