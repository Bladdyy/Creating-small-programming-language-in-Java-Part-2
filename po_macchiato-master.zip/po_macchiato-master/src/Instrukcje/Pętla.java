package Instrukcje;

import Błędy.DzieleniePrzezZero;
import Wyrażenia.*;

public class Pętla extends Instrukcja{
    private Zmienna zmienna; // Wyrażenia.Zmienna iterująca po pętli.
    private Wyrażenie wyrażenie; // Granica, do której pętla ma się wykonywać.
    private Instrukcja[] instrukcje; // Instrukcje w pętli
    private Blok blok; // Instrukcje.Blok, w którym pętla się znajduje.
    public void wykonujInstrukcję() throws DzieleniePrzezZero { // Dodaje pętlę for do bloku.

        int powtórzenia = wyrażenie.getWartość() - zmienna.getWartość(); // Powtórzenia pętli.

        if (powtórzenia > 0) { // Jeśli ilość powtórzeń jest większa od zera.
            Instrukcja[] wszystkieinstrukcje = new Instrukcja[(instrukcje.length + 1) * powtórzenia];
            int indeks = 0;
            for (int x = 0; x < powtórzenia; x++) {
                // Przepisuje instrukcje do tablicy z instrukcjami.
                for (int i = 0; i < instrukcje.length; i++) {
                    wszystkieinstrukcje[indeks] = instrukcje[i];
                    indeks++;
                }
                wszystkieinstrukcje[indeks] = new ZmieńWartośćZmiennej(zmienna.getNazwa(),
                        new Literał(zmienna.getWartość() + x + 1), blok);
                indeks++;
            }
            // Dodaje na koniec pętli zwiększanie zmiennej pętli o 1.
            // Dodaje do aktualnego bloku instrukcje.
            blok.dodajInstrukcjeOdPętli(wszystkieinstrukcje);
        }
    }
    public String toString()
    {
        return "Następne polecenie: Pętla For o zmiennej " + String.valueOf(zmienna.getNazwa());
    }
    public Pętla (Zmienna zmienna, Wyrażenie wyrażenie, Instrukcja[] instrukcje, Blok blok)
    {
        this.zmienna = zmienna;
        this.wyrażenie = wyrażenie;
        this.instrukcje = instrukcje;
        this.blok = blok;
    }
}
