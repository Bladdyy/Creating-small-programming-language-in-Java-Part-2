package Instrukcje;

import Błędy.DzieleniePrzezZero;

public abstract class Instrukcja {
        public abstract void wykonujInstrukcję() throws DzieleniePrzezZero; // Wykonuje instrukcję danego typu.
        public abstract String toString();
}
