package Instrukcje;

import Błędy.*;
import Wyrażenia.*;

public class ZmieńWartośćZmiennej extends Instrukcja {
    private char nazwa; // Nazwa zmiennej, której wartość jest zmieniana.
    private Wyrażenie wyrażenie; // Nowa wartość zmiennej.
    private Blok blok; // Instrukcje.Blok, w którym szuka zmiennej.
    public void wykonujInstrukcję() throws DzieleniePrzezZero// Zmienia wartość zmiennej.
    {
        boolean znaleziona = false; // Czy zmienna jest w tablicy zmiennych.
        int indeks = 0;
        Zmienna[] zmienne = blok.getZmienne(); // Tablica zmiennych w danym bloku.
        try {
            if (blok.getIleZmiennych() == 0) // Jeśli zmienna została znaleziona.
            {
                throw new Nieznaleziona("W AKTUALNYM BLOKU NIE ISTNIEJE ZMIENNA O NAZWIE "
                        + String.valueOf(nazwa));
            }
        }
        catch (Nieznaleziona e)
        {
            System.out.println(e.getMessage());
            System.out.println("Błąd w " + this);
            System.out.println("Nie ma zmiennych w tym bloku");
            System.exit(1);
        }
        while (!znaleziona && indeks < blok.getIleZmiennych()) // Szuka zmiennej.
        {
            if (nazwa == zmienne[indeks].getNazwa()) {
                znaleziona = true;
                indeks--;
            }
            indeks++;
        }
        try {
            if (znaleziona) // Jeśli zmienna została znaleziona.
            {
                zmienne[indeks].setWartość(wyrażenie.getWartość()); // Zmienia wartość na wartość wyrażenia.
            } else {
                throw new Nieznaleziona("W AKTUALNYM BLOKU NIE ISTNIEJE ZMIENNA O NAZWIE " +
                        String.valueOf(nazwa));
            }
        }
        catch (Nieznaleziona e)
        {
            System.out.println(e.getMessage());
            System.out.println("Błąd w " + this);
            System.out.println("Aktualne wartości zmiennych to");
            for (int i = 0; i < blok.getIleZmiennych(); i++)
            {
                System.out.println(blok.getZmienne()[i] + " o wartości " + blok.getZmienne()[i].getWartość());
            }
            System.exit(1);
        }
    }
    public String toString()
    {
        return "Następne polecenie: Zmiana wartości zmiennej z " + String.valueOf(nazwa) + " na " + wyrażenie.toString();
    }

    public ZmieńWartośćZmiennej(char nazwa, Wyrażenie wyrażenie, Blok blok)
    {
        this.nazwa = nazwa;
        this.wyrażenie = wyrażenie;
        this.blok = blok;
    }
}

