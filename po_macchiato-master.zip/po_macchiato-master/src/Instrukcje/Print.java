package Instrukcje;

import Błędy.DzieleniePrzezZero;
import Wyrażenia.*;

public class Print extends Instrukcja {
    private Wyrażenie wyrażenie; // Wyrażenia.Wyrażenie, którego wartość jest wypisywana.
    public void wykonujInstrukcję() throws DzieleniePrzezZero // Wypisuje wartość wyrażenia.
    {
        System.out.println(wyrażenie.getWartość());
    }
    public String toString()
    {
        return "Następne polecenie: Print " + wyrażenie.toString();
    }
    public Print(Wyrażenie wyrażenie)
    {
        this.wyrażenie = wyrażenie;
    }
}
