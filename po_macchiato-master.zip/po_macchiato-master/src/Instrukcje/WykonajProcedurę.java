package Instrukcje;

import Błędy.DzieleniePrzezZero;
import Macchiato.Macchiato;
import Procedury.Procedura;
import Wyrażenia.*;

public class WykonajProcedurę extends Instrukcja{
    private Macchiato program;
    private Procedura procedura; // Aktywowana procedura.
    private Wyrażenie[] wartości; // Wartości parametrów procedury.
    private Blok aktualnyblok; // Blok, który aktywuje procedurę.

    public void wykonujInstrukcję() throws DzieleniePrzezZero// Wykonuje instrukcję danego typu.
    {
        Zmienna[] parametry = procedura.getParametry();
        int[] starewartości = new int[parametry.length]; // Zapamiętuje wartości parametrów procedury sprzed wywołania jej z nowymi wartościami.
        for (int i = 0; i < parametry.length; i++)
        {
            starewartości[i] = parametry[i].getWartość(); // Zapisuje stare wartości parametrów.
        }

        for (int i = 0; i < parametry.length; i++)
        {
            parametry[i].setWartość(wartości[i].getWartość()); // Ustawia parametrom procedury nowe wartości.
        }

        Instrukcja[] treść = procedura.getTreśćProcedury();
        program.kolejnaProcedura(); // Rozpoczyna wykonywanie procedury.

        // Dodaje do aktualnego bloku instrukcje procedury oraz instrukcję kończącą procedurę.
        aktualnyblok.dodajInstrukcjeProcedury(procedura.getTreśćProcedury(), new SkończProcedurę(procedura, program, starewartości));


    }

    public  String toString() {return "Następne polecenie: Wykonanie Procedury o nazwie " + procedura.getNazwa();}
    public WykonajProcedurę (Procedura procedura, Macchiato program, Wyrażenie[] wartości, Blok aktualnyblok)
    {
        this.procedura = procedura;
        this.program = program;
        this.wartości = wartości;
        this.aktualnyblok = aktualnyblok;
    }
}
