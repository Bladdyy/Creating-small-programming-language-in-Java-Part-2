import Instrukcje.*;
import Macchiato.Macchiato;
import Wyrażenia.*;

import java.util.List;

// Większość przykładowych programów jest zawarta w testach.

public class Main {
    public static void main(String[] args) {

        // Przykładowy program numer 1.

//        Macchiato program = new Macchiato();
//
//        program.stwórzBlok()
//                .deklarujZmienną('a', Literał.wartość(100000))
//                .zacznijDeklaracjęProcedury("out", new char[]{'a', 'b'})
//                .skończDeklaracjęProcedury(new Instrukcja[]{program.nowyPrint(program.getZmienna('a')),
//                program.nowaInstrukcjaWarunkowa(program.getZmienna('a'), "<", Literał.wartość(3),program.noweWykonajProcedurę("out", new Wyrażenie[]{Dodawanie.dodaj(program.getZmienna('a'), Literał.wartość(1)), Literał.wartość(3)})),
//                program.nowaInstrukcjaWarunkowa(program.getZmienna('a'), "<", Literał.wartość(3),program.nowyPrint(Dodawanie.dodaj(program.getZmienna('a'), Literał.wartość(1000))))})
//                .stwórzWykonajProcedurę("out", new Wyrażenie[]{Literał.wartość(0), Literał.wartość(3)})
//                .stwórzPrint(program.getZmienna('a'))
//                .koniecBloku()
//                .wykonajMacchiato(true);


        // Przykładowy program numer 2.
//
//        Macchiato program = new Macchiato();
//
//
//        program.stwórzBlok()
//            .deklarujZmienną('x', Literał.wartość(57))
//            .deklarujZmienną('y', Literał.wartość(15))
//            .zacznijDeklaracjęProcedury("out", new char[]{'a'})
//            .skończDeklaracjęProcedury(new Instrukcja[]{program.nowyPrint(program.getZmienna('a'))})
//            .stwórzZmieńWartośćZmiennej('x', Odejmowanie.odejmij(program.getZmienna('x'), program.getZmienna('y')))
//            .stwórzWykonajProcedurę("out", new Wyrażenie[]{program.getZmienna('x')})
//            .stwórzWykonajProcedurę("out", new Wyrażenie[]{Literał.wartość(125)})
//            .koniecBloku()
//            .wykonajMacchiato(true);

        // Przykładowy program numer 4.

//        Macchiato program = new Macchiato();
//
//
//        program.stwórzBlok()
//                .deklarujZmienną('x', Literał.wartość(57))
//                .deklarujZmienną('y', Literał.wartość(15))
//                .zacznijDeklaracjęProcedury("out", new char[]{'a'})
//                .deklarujZmienną('z', Literał.wartość(23))
//                .skończDeklaracjęProcedury(new Instrukcja[]{program.nowyPrint(program.getZmienna('a'))})
//                .stwórzZmieńWartośćZmiennej('x', Odejmowanie.odejmij(program.getZmienna('x'), program.getZmienna('y')))
//                .stwórzWykonajProcedurę("out", new Wyrażenie[]{program.getZmienna('x')})
//                .stwórzWykonajProcedurę("out", new Wyrażenie[]{Literał.wartość(125)})
//                .koniecBloku()
//                .wykonajMacchiato(true);

        // Przykładowy program numer 5.
//
//        Macchiato program = new Macchiato();
//
//
//        program.stwórzBlok()
//                .zacznijDeklaracjęProcedury("out", new char[]{'a'})
//                .zacznijDeklaracjęProcedury("wypiszmnie", new char[]{'b'})
//                .skończDeklaracjęProcedury(new Instrukcja[]{program.nowyPrint(program.getZmienna('b'))})
//                .skończDeklaracjęProcedury(new Instrukcja[]{program.noweWykonajProcedurę("wypiszmnie", new Wyrażenie[]{program.getZmienna('a')})})
//                .stwórzWykonajProcedurę("out", new Wyrażenie[]{Literał.wartość(3)})
//                .koniecBloku()
//                .wykonajMacchiato(true);


        // Przykładowy program numer 6.
//
//        Macchiato program = new Macchiato();
//
//        program.stwórzBlok()
//            .deklarujZmienną('x', Literał.wartość(101))
//            .deklarujZmienną('y', Literał.wartość(1))
//            .zacznijDeklaracjęProcedury("out", new char[]{'a'})
//            .skończDeklaracjęProcedury(new Instrukcja[]{program.nowyPrint(Dodawanie.dodaj(program.getZmienna('a'), program.getZmienna('x')))})
//            .stwórzZmieńWartośćZmiennej('x', Odejmowanie.odejmij(program.getZmienna('x'), program.getZmienna('y')))
//            .stwórzWykonajProcedurę("out", new Wyrażenie[]{program.getZmienna('x')})
//            .stwórzWykonajProcedurę("out", new Wyrażenie[]{Literał.wartość(100)})
//            .stwórzBlok()
//            .deklarujZmienną('x', Literał.wartość(10))
//            .stwórzWykonajProcedurę("out", new Wyrażenie[]{program.getZmienna('x')})
//            .wykonajMacchiato(true);



        // Przykładowy program do poprzedniego Macchiato.

//        Macchiato program = new Macchiato(); // Odpala Macchiato.Macchiato
//
//
//        // Poniżej zapisany jest przykładowy kod z polecenia w składni Macchiato.Macchiato.
//
//        // KOD MACCHIATO:
//
//        // Główny blok.
//        program.stwórzBlok();
//
//        // var n 30
//        program.deklarujZmienną('n', new Literał(30));
//
//        // Zmienne należy deklarować na początku bloku (więc to jest deklaracja zmiennej 'k' z pętli for)
//        program.deklarujZmienną('k', new Literał(0));
//
//        // Instrukcje.Blok, który będzie wewnątrz głównej pętli for.
//        Blok blok = program.nowyBlok();
//
//        // var p 1
//        program.deklarujZmienną('p', new Literał(1));
//
//        // Zmienne należy deklarować na początku (więc to jest deklaracja zmiennej 'i' z pętli for)
//        program.deklarujZmienną('i', new Literał(0));
//
//        // k := k + 2
//        program.stwórzZmieńWartośćZmiennej('k', new Dodawanie(program.getZmienna('k'), new Literał(2)));
//
//        // Instrukcje wewnętrznej pętli for.
//        Instrukcja[] instrukcjedopętliwewnętrznej = new Instrukcja[]{program.nowyZmieńWartośćZmiennej('i',
//            new Dodawanie(program.getZmienna('i'), new Literał(2))),
//                program.nowaInstrukcjaWarunkowa(new Modulo(program.getZmienna('k'), program.getZmienna('i')), "=", new Literał(0),
//                        program.nowyZmieńWartośćZmiennej('p', new Literał(0)))};
//
//        // for i k-2
//        program.stwórzPętla(program.getZmienna('i'), new Odejmowanie(program.getZmienna('k'), new Literał(2)), instrukcjedopętliwewnętrznej);
//
//        // if p = 1
//        program.stwórzInstrukcjaWarunkowa(program.getZmienna('p'),"=", new Literał(1), program.nowyPrint(program.getZmienna('k')));
//
//        // Koniec bloku trafiającego do pętli.
//        program.koniecBloku();
//
//        // Instrukcje do pętli zewnętrznej (blok)
//        Instrukcja[] instrukcjepętli = new Instrukcja[]{blok};
//
//        // for k n-1
//        program.stwórzPętla(program.getZmienna('k'), new Odejmowanie(program.getZmienna('n'), new Literał(1)),
//                instrukcjepętli);
//
//        // Koniec bloku zewnętrznego.
//        program.koniecBloku();
//
//        // Odpalenie programu (false oznacza bez debuggera, true z debuggerem).
//        program.wykonajMacchiato(true);
    }
}