
import Instrukcje.*;
import Macchiato.Macchiato;
import Wyrażenia.*;
import org.junit.*;


import static org.junit.Assert.*;
public class TestyInstrukcji extends Testy{

    @Test
    public void print()
    {
        przygotuj();
        Print print = new Print(Literał.wartość(3));
        print.wykonujInstrukcję();
        assertEquals("3\r\n", buffor.toString());
        zamknij();
    }

    @Test
    public void blok()
    {
        Macchiato program = new Macchiato();
        assertEquals(-1, program.getZagnieżdżenie());
        program.stwórzBlok();
        assertEquals(0, program.getZagnieżdżenie());
    }

    @Test
    public void deklaracjaZmiennej()
    {
        Macchiato program = new Macchiato();
        program.stwórzBlok()
                .deklarujZmienną('a', Literał.wartość(3));
        Zmienna zmienna = program.getZmienna('a');
        assertEquals('a', zmienna.getNazwa());
        assertEquals(3, zmienna.getWartość());
        assertEquals(0, zmienna.getBlokzadeklarowania());
    }

    @Test
    public void ifek(){
        Macchiato program = new Macchiato();

        przygotuj();
        program.stwórzBlok()
                .stwórzInstrukcjaWarunkowa(Literał.wartość(3),"=",
                        Dodawanie.dodaj(Literał.wartość(7),Literał.wartość(-4)),
                        program.nowyPrint(Literał.wartość(1111)))
                .koniecBloku()
                .wykonajMacchiato(false);
        assertEquals("1111\r\nProgram się zakończył.\r\n", buffor.toString());
        zamknij();
    }

    @Test
    public void ifElse(){
        Macchiato program = new Macchiato();

        przygotuj();
        program.stwórzBlok()
                .stwórzInstrukcjaWarunkowa(Literał.wartość(3),"=",
                        Dodawanie.dodaj(Literał.wartość(7),Literał.wartość(-3)),
                        program.nowyPrint(Literał.wartość(1111)),program.nowyPrint(Literał.wartość(-1)))
                .koniecBloku()
                .wykonajMacchiato(false);
        assertEquals("-1\r\nProgram się zakończył.\r\n", buffor.toString());
        zamknij();
    }

    @Test
    public void petla()
    {
        Macchiato program = new Macchiato();

        przygotuj();
        program.stwórzBlok()
                .deklarujZmienną('a', Literał.wartość(0))
                .stwórzPętla(program.getZmienna('a'), Literał.wartość(5), new Instrukcja[]
                        {program.nowyPrint(program.getZmienna('a'))})
                .koniecBloku()
                .wykonajMacchiato(false);
        assertEquals("0\r\n1\r\n2\r\n3\r\n4\r\nProgram się zakończył.\r\n", buffor.toString());
        zamknij();
    }

    @Test
    public void zmianaWartosciZmiennej()
    {
        Macchiato program =  new Macchiato();

        przygotuj();
        program.stwórzBlok()
                .deklarujZmienną('a', Literał.wartość(44))
                .stwórzZmieńWartośćZmiennej('a', Dodawanie.dodaj(program.getZmienna('a'), program.getZmienna('a')))
                .stwórzPrint(program.getZmienna('a'))
                .koniecBloku()
                .wykonajMacchiato(false);
        assertEquals("88\r\nProgram się zakończył.\r\n", buffor.toString());
        zamknij();
    }
    @Test
    public void wykonajProcedure()
    {
        Macchiato program =  new Macchiato();

        przygotuj();
        program.stwórzBlok()
                .deklarujZmienną('x',Literał.wartość(4))
                .deklarujZmienną('y', Literał.wartość(3))
                .zacznijDeklaracjęProcedury("wypiszsume", new char[]{})
                .skończDeklaracjęProcedury(new Instrukcja[]{program.nowyPrint(Dodawanie.dodaj(program.getZmienna('x'),program.getZmienna('y')))})
                .stwórzWykonajProcedurę("wypiszsume", new Wyrażenie[]{})
                .koniecBloku()
                .wykonajMacchiato(false);
        assertEquals("7\r\nProgram się zakończył.\r\n", buffor.toString());
        zamknij();
    }

}
