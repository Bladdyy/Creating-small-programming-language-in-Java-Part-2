import Wyrażenia.*;
import org.junit.*;
import static org.junit.Assert.*;

public class TestyWyrazen extends Testy{

    @Test
    public void dodawnie() {
        Dodawanie dodawanie = new Dodawanie(Literał.wartość(15), Literał.wartość(4));
        assertEquals(19,dodawanie.getWartość());
    }
    @Test
    public void odejmowanie() {
        Odejmowanie odejmowanie = new Odejmowanie(Literał.wartość(15), Literał.wartość(4));
        assertEquals(11, odejmowanie.getWartość());
    }

    @Test
    public void mnożenie() {
        Mnożenie mnożenie = new Mnożenie(Literał.wartość(15), Literał.wartość(4));
        assertEquals(60, mnożenie.getWartość());
    }
    @Test
    public void dzielenie() {
        Dzielenie dzielenie = new Dzielenie(Literał.wartość(15), Literał.wartość(4));
        assertEquals(3, dzielenie.getWartość());
    }

    @Test
    public void modulo() {
        Modulo modulo = new Modulo(Literał.wartość(15), Literał.wartość(4));
        assertEquals(3, modulo.getWartość());
    }

    @Test
    public void literał(){
        Literał literał = new Literał(15);
        assertEquals(15, literał.getWartość());
    }

    @Test
    public void zmiennaWartość()
    {
        Zmienna zmienna = new Zmienna('a', 15, 0);
        assertEquals(15, zmienna.getWartość());
        zmienna.setWartość(33);
        assertEquals(33, zmienna.getWartość());
    }

    @Test
    public void zmiennaNazwa()
    {
        Zmienna zmienna = new Zmienna('a', 15, 0);
        assertEquals('a', zmienna.getNazwa());
    }


}

