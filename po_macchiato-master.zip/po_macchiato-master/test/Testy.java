import java.io.ByteArrayOutputStream;
import java.io.PrintStream;

// W nazwach klas testów oraz w metodach nie używam polskich znaków,
// ponieważ gdy ich używam, testy nie chcą się odpalać pojedynczo.

public class Testy{
    protected final PrintStream wyjście = System.out;
    protected final ByteArrayOutputStream buffor = new ByteArrayOutputStream();

    protected void przygotuj() {
        System.setOut(new PrintStream(buffor));
    }
    protected void zamknij()
    {
        System.setOut(wyjście);
    }
}
