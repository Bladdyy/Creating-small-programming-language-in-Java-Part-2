import Instrukcje.Instrukcja;
import Macchiato.Macchiato;
import Wyrażenia.*;
import org.junit.*;


import static org.junit.Assert.*;

public class TestyProcedur extends Testy{

    @Test
    public void deklaracjaprocedurywprocedurze()
    {
        przygotuj();
        Macchiato program = new Macchiato();

        program.stwórzBlok()
                .zacznijDeklaracjęProcedury("out", new char[]{'a'})
                .zacznijDeklaracjęProcedury("wypiszmnie", new char[]{'b'})
                .skończDeklaracjęProcedury(new Instrukcja[]{program.nowyPrint(program.getZmienna('b'))})
                .skończDeklaracjęProcedury(new Instrukcja[]{program.noweWykonajProcedurę("wypiszmnie", new Wyrażenie[]{program.getZmienna('a')})})
                .stwórzWykonajProcedurę("out", new Wyrażenie[]{Literał.wartość(777)})
                .koniecBloku()
                .wykonajMacchiato(false);
        assertEquals("777\r\nProgram się zakończył.\r\n", buffor.toString());
        zamknij();
    }

    @Test
    public void rekurencja() {
        przygotuj();
        Macchiato program = new Macchiato();

        program.stwórzBlok()
                .zacznijDeklaracjęProcedury("out", new char[]{'a'})
                .skończDeklaracjęProcedury(new Instrukcja[]{program.nowyPrint(program.getZmienna('a')),
                        program.nowaInstrukcjaWarunkowa(program.getZmienna('a'), "<", Literał.wartość(5),program.noweWykonajProcedurę("out", new Wyrażenie[]{Dodawanie.dodaj(program.getZmienna('a'), Literał.wartość(1))})),
                        program.nowaInstrukcjaWarunkowa(program.getZmienna('a'), "<", Literał.wartość(5),program.nowyPrint(Dodawanie.dodaj(program.getZmienna('a'), Literał.wartość(1000))))})
                .stwórzWykonajProcedurę("out", new Wyrażenie[]{Literał.wartość(0), Literał.wartość(3)})
                .koniecBloku()
                .wykonajMacchiato(false);
        assertEquals("0\r\n1\r\n2\r\n3\r\n4\r\n5\r\n1004\r\n1003\r\n1002\r\n1001\r\n1000\r\nProgram się zakończył.\r\n", buffor.toString());
        zamknij();
    }

    @Test
    public void proceduraZPolecenia1() {
        Macchiato program = new Macchiato();

        przygotuj();
        program.stwórzBlok()
                .deklarujZmienną('x', Literał.wartość(57))
                .deklarujZmienną('y', Literał.wartość(15))
                .zacznijDeklaracjęProcedury("out", new char[]{'a'})
                .skończDeklaracjęProcedury(new Instrukcja[]{program.nowyPrint(program.getZmienna('a'))})
                .stwórzZmieńWartośćZmiennej('x', Odejmowanie.odejmij(program.getZmienna('x'), program.getZmienna('y')))
                .stwórzWykonajProcedurę("out", new Wyrażenie[]{program.getZmienna('x')})
                .stwórzWykonajProcedurę("out", new Wyrażenie[]{Literał.wartość(125)})
                .koniecBloku()
                .wykonajMacchiato(false);
        assertEquals("42\r\n125\r\nProgram się zakończył.\r\n", buffor.toString());
        zamknij();
    }

    @Test
    public void proceduraZPolecenia2() {
        Macchiato program = new Macchiato();
        przygotuj();
        program.stwórzBlok()
                .deklarujZmienną('x', Literał.wartość(101))
                .deklarujZmienną('y', Literał.wartość(1))
                .zacznijDeklaracjęProcedury("out", new char[]{'a'})
                .skończDeklaracjęProcedury(new Instrukcja[]{program.nowyPrint(Dodawanie.dodaj(program.getZmienna('a'), program.getZmienna('x')))})
                .stwórzZmieńWartośćZmiennej('x', Odejmowanie.odejmij(program.getZmienna('x'), program.getZmienna('y')))
                .stwórzWykonajProcedurę("out", new Wyrażenie[]{program.getZmienna('x')})
                .stwórzWykonajProcedurę("out", new Wyrażenie[]{Literał.wartość(100)})
                .stwórzBlok()
                .deklarujZmienną('x', Literał.wartość(10))
                .stwórzWykonajProcedurę("out", new Wyrażenie[]{program.getZmienna('x')})
                .koniecBloku()
                .wykonajMacchiato(false);
        assertEquals("200\r\n200\r\n110\r\nProgram się zakończył.\r\n", buffor.toString());
        zamknij();
    }

}
